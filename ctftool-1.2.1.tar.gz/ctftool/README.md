# ctftool — полуавтоматический триаж бинарников для CTF (pwn / reverse)

Инструмент для подготовки к соревнованиям вроде **ECSC**. Скармливаешь бинарник —
получаешь **чёткий отчёт**: защиты, опасные функции, win-функции, ROP-гаджеты,
подсказки по уязвимостям и **приоритизированный план атаки** + готовый **скелет
эксплойта** под pwntools.

> Без ИИ и без интернета. Под капотом — проверенные движки: `pwntools`,
> `capstone`, `pyelftools`, `ROPgadget`. Инструмент их оркестрирует и объясняет
> результат человеческим языком.

**Важно, честно:** это НЕ «решить за тебя 100%». Такого не существует — задачи
ECSC специально так делают. Это ускоритель: он снимает всю рутину (checksec,
поиск гаджетов, строк, сборка каркаса эксплойта), чтобы ты тратила время на суть.
На тестовом ret2win по подсказкам тулкита эксплойт доводится до shell за минуты.

## Установка

```bash
cd ctftool
bash install.sh                 # базовые зависимости + враппер ./ctftool
# или как пакет (команда ctftool доступна из любого места):
pip install --break-system-packages -e .
pip install --break-system-packages -e '.[solve]'   # + angr для --solve
```

Нужен Linux + Python 3.9+. `gdb` желателен (для автопоиска offset через corefile).
`angr` (для символьного решения) тяжёлый и ставится отдельно — он опционален.

## Использование

```bash
# базовый триаж + отчёт
python3 -m ctftool ./challenge

# + сгенерировать скелет эксплойта и JSON
python3 -m ctftool ./challenge --skeleton exploit.py --json out.json

# дизассемблировать конкретную функцию (для reverse)
python3 -m ctftool ./challenge --disasm main

# если к таску дали libc — включить поиск one-gadget
python3 -m ctftool ./challenge --libc ./libc.so.6

# heap-анализ: alloc/free сайты + version-aware tcache/fastbin подсказки
python3 -m ctftool ./challenge --heap

# авто-сборка ROP-цепочки на system/execve (точнее с --libc)
python3 -m ctftool ./challenge --ropchain --libc ./libc.so.6

# символьное решение reverse/keygen через angr:
#   найти ввод, при котором печатается "Correct" (и отсечь "Wrong")
python3 -m ctftool ./crackme --solve-find Correct --solve-avoid Wrong
#   или добраться до адреса-цели
python3 -m ctftool ./crackme --solve-addr 0x401337
#   + сохранить отдельный переиспользуемый solver-скрипт
python3 -m ctftool ./crackme --solve-find Correct --solve-script solve.py

# СТАТИЧЕСКИЕ / STRIPPED бинарники:
#   xref строк → адрес кода, который её использует (ищем парсер/логику без символов)
python3 -m ctftool ./chal --xref
python3 -m ctftool ./chal --xref "malformed"     # фильтр по подстроке
#   syscall-сайты + writable-регионы + write-гаджеты (авто для статики)
python3 -m ctftool ./chal --static
```

> `-m ctftool` запускай из корня проекта; после `pip install -e .` команда
> `ctftool` работает из любой папки.

Удобный враппер (после install.sh):

```bash
./ctftool ./challenge --skeleton
```

## Что показывает отчёт

| Блок | Что даёт |
|------|----------|
| **Protections** | PIE / NX / Canary / RELRO / Fortify / static / stripped — как checksec, но с пояснением «что это значит для атаки» |
| **Dangerous functions** | gets/scanf/strcpy/printf/system… с уровнем опасности и почему |
| **Win / backdoor funcs** | функции вида win/shell/get_flag — частая цель ret2win |
| **ROP gadgets** | ключевые гаджеты (pop rdi; ret, leave; ret, syscall…) с адресами |
| **/bin/sh strings** | адреса строк для ret2system |
| **Reverse flags** | упаковка (UPX…), анти-дебаг (ptrace), энтропия |
| **Keygen hints** | частые константы сравнений (длины паролей, магические числа) |
| **String xrefs** (`--xref`) | строка → адрес кода, который её использует — находит логику/парсер в stripped-бинарниках |
| **Static analysis** (`--static`) | syscall-сайты с номерами (execve/mprotect…), writable-регионы (.bss/.data), write-гаджеты — закрывает слепоту на статике без импортов |
| **Heap analysis** (`--heap`) | alloc/free сайты, запахи UAF/double-free, tcache/fastbin подсказки под версию glibc |
| **Auto ROP chain** (`--ropchain`) | авто-сборка system/execve цепочки (pwntools ROP + fallback на syscall-цепочку) |
| **Symbolic solve** (`--solve-*`) | angr находит ввод, ведущий к success-строке или адресу — для reverse/keygen |
| **Attack plan** | пронумерованные шаги P1–P4: что делать, почему, как |
| **Exploit skeleton** | готовый pwntools-скрипт под findings, с хелпером поиска offset |

## Как это использовать на соревновании

1. `python3 -m ctftool ./chal --skeleton expl.py` — за секунды видишь класс бага и план.
2. Идёшь по шагам P1 → P2. Для pwn первым делом находишь offset
   (`python3 expl.py` запустит `find_offset()` при наличии corefile).
3. Правишь TODO в сгенерированном `expl.py`, запускаешь локально:
   `python3 expl.py GDB=1`, затем на ремоуте `python3 expl.py REMOTE=1`.
4. Для reverse — `--disasm <func>` и блок «keygen hints» дают быстрый старт
   без открытия Ghidra.

> ⚠️ Перед ECSC проверь правила этапа: иногда ограничивают используемый
> инструментарий во время самого соревнования. Готовить и приносить свой тулкит —
> стандартная и разрешённая практика, но убедись сама.

## Структура

```
ctftool/
  __main__.py   — CLI и сборка отчёта
  triage.py     — защиты, символы, опасные функции, строки
  pwn_mod.py    — ROP-гаджеты, GOT/PLT, /bin/sh, one-gadget, cyclic
  rev_mod.py    — упаковка, анти-дебаг, энтропия, дизасм, константы
  heap_mod.py   — alloc/free сайты, UAF/double-free, tcache/fastbin хинты
  static_mod.py — xref строк, syscall-сайты, writable-регионы, write-гаджеты
  ropchain.py   — авто-сборка ROP-цепочки (pwntools + syscall-fallback)
  solve_mod.py  — символьное решение через angr
  plan.py       — движок плана атаки (объяснимые правила)
  skeleton.py   — генератор pwntools-скелета
  ui.py         — форматирование вывода
samples/        — учебные уязвимые бинарники для проверки
```

## Лицензия и ответственное использование

MIT (см. `LICENSE`). Инструмент предназначен для **легальной** работы: CTF,
обучение, анализ бинарников, которыми ты владеешь или на тест которых есть
разрешение. Не применяй против чужих систем без согласия.

## Расширять под себя

- Новые опасные функции → словарь `DANGEROUS` в `triage.py`.
- Новые правила плана → функция `build()` в `plan.py` (просто `add(prio, title, why, how)`).
- Новые гаджеты → `GADGET_WANTS` в `pwn_mod.py`.
