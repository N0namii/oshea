"""ctftool — semi-automatic binary triage & exploit-scaffolding toolkit for CTF pwn/rev.

No AI / no network required. Orchestrates well-known engines (pwntools, capstone,
pyelftools, ROPgadget) plus built-in analysis to produce a clear, prioritized report
and an exploit skeleton you can fill in.
"""
__version__ = "1.2.1"
