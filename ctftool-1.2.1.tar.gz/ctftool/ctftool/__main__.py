"""ctftool CLI — one command to triage a binary and print a clear, actionable report.

Usage:
    python3 -m ctftool <binary> [--libc LIBC] [--disasm SYMBOL]
                       [--skeleton OUT.py] [--json OUT.json] [--no-gadgets]
                       [--heap] [--ropchain] [--solve-find STR | --solve-addr ADDR]
"""
import argparse
import json
import os
import sys

from . import triage as T
from . import pwn_mod as P
from . import rev_mod as R
from . import plan as PLAN
from . import skeleton as SK
from . import heap_mod as H
from . import ropchain as RC
from . import static_mod as ST
from . import ui


def _print_protections(p):
    def mark(ok, good="ENABLED", bad="missing"):
        return ui.green(good) if ok else ui.red(bad)
    print(ui.section("Protections (checksec)"))
    print(ui.kv("Arch", f"{p.arch} / {p.bits}-bit / {p.endian}-endian"))
    print(ui.kv("PIE", ui.yellow("yes (ASLR on image → need a leak)") if p.pie
                else ui.green("no (fixed addresses)")))
    print(ui.kv("NX (no-exec stack)", mark(p.nx) if p.nx else ui.red("DISABLED → shellcode OK")))
    print(ui.kv("Stack canary", ui.red("present (must leak)") if p.canary
                else ui.green("none (overflow is clean)")))
    relro_col = {"Full": ui.red("Full (GOT read-only)"),
                 "Partial": ui.yellow("Partial (GOT writable)"),
                 "No": ui.green("None (GOT writable)")}
    print(ui.kv("RELRO", relro_col.get(p.relro, p.relro)))
    print(ui.kv("Fortify (_chk)", ui.yellow("yes") if p.fortify else ui.grey("no")))
    print(ui.kv("Linking", "static" if p.static else "dynamic"))
    print(ui.kv("Symbols", ui.yellow("stripped") if p.stripped else ui.green("present")))
    if p.rpath or p.runpath:
        print(ui.kv("RPATH/RUNPATH", ui.yellow(str(p.rpath + p.runpath))))


def main(argv=None):
    ap = argparse.ArgumentParser(prog="ctftool",
        description="Semi-automatic binary triage & exploit scaffolding for CTF pwn/rev.")
    ap.add_argument("binary", help="target binary (ELF)")
    ap.add_argument("--libc", help="path to challenge libc (enables one-gadget scan)")
    ap.add_argument("--disasm", metavar="SYM", help="disassemble a named function")
    ap.add_argument("--skeleton", metavar="OUT", nargs="?", const="exploit.py",
                    help="write a pwntools exploit skeleton (default exploit.py)")
    ap.add_argument("--json", metavar="OUT", help="also dump findings as JSON")
    ap.add_argument("--no-gadgets", action="store_true", help="skip ROP gadget search")
    ap.add_argument("--heap", action="store_true",
                    help="run heap analysis (alloc/free sites, tcache/fastbin hints)")
    ap.add_argument("--ropchain", action="store_true",
                    help="try to auto-build a system/execve ROP chain")
    ap.add_argument("--solve-find", metavar="STR",
                    help="angr: find stdin that makes the program print STR")
    ap.add_argument("--solve-addr", metavar="ADDR",
                    help="angr: find stdin that reaches ADDR (hex, e.g. 0x401337)")
    ap.add_argument("--solve-avoid", metavar="STR",
                    help="angr: prune paths that print STR (e.g. 'Wrong')")
    ap.add_argument("--solve-timeout", type=int, default=180,
                    help="seconds before angr gives up (default 180)")
    ap.add_argument("--solve-script", metavar="OUT",
                    help="write a standalone angr solver script")
    ap.add_argument("--xref", metavar="STR", nargs="?", const="",
                    help="map interesting strings -> code addresses that reference them "
                         "(optionally filter by substring). Great for stripped binaries. "
                         "On static binaries, libc-internal strings are deprioritized.")
    ap.add_argument("--xref-all", action="store_true",
                    help="with --xref: also show libc/toolchain-internal strings "
                         "(off by default so the app's own strings surface)")
    ap.add_argument("--static", action="store_true",
                    help="run static-binary analysis (syscall sites, writable regions, "
                         "write gadgets) — auto-enabled for statically linked binaries")
    ap.add_argument("--max-strings", type=int, default=40)
    args = ap.parse_args(argv)

    if not os.path.exists(args.binary):
        print(ui.red(f"no such file: {args.binary}"), file=sys.stderr)
        return 2

    print(ui.header(f"ctftool — {os.path.basename(args.binary)}"))

    # ---- triage ----
    t = T.run(args.binary)
    print(ui.kv("File type", t.filetype))
    if t.filetype != "ELF":
        print(ui.yellow("\nNot an ELF — showing interesting strings only.\n"))
        for off, s in t.strings[:args.max_strings]:
            print(f"  {off:#08x}  {s}")
        return 0

    _print_protections(t.prot)
    if t.libc_version:
        print(ui.kv("Embedded libc ver", t.libc_version))

    # ---- dangerous functions ----
    print(ui.section("Dangerous / interesting functions"))
    if t.dangerous:
        for name, s, why in t.dangerous:
            print(f"  {ui.sev(s)} {ui.bold(name):<28} {ui.grey(why)}")
    else:
        print(ui.grey("  none of the usual sinks were imported"))

    # ---- win functions ----
    if t.win_funcs:
        print(ui.section("Possible 'win'/backdoor functions"))
        for name, addr in t.win_funcs:
            print(f"  {ui.green('★')} {ui.bold(name):<24} {hex(addr)}")

    # ---- pwn analysis ----
    gadgets, got, binsh = {}, {}, []
    fmt_sinks, fmt_srcs = [], []
    if not args.no_gadgets:
        gadgets, had = P.find_key_gadgets(args.binary)
        if gadgets:
            print(ui.section("Key ROP gadgets"))
            for want, (addr, insn) in gadgets.items():
                note = P.GADGET_WANTS.get(want, "")
                print(f"  {ui.cyan(hex(addr))}  {ui.bold(insn):<28} {ui.grey(note)}")
        elif had is False:
            print(ui.grey("\n  (ROPgadget not installed — gadget search skipped)"))

    got = P.plt_got(args.binary)
    binsh = P.bin_sh_addresses(args.binary)
    if binsh:
        print(ui.section("Embedded '/bin/sh' / 'sh' strings"))
        for off, va, s in binsh[:8]:
            va_s = hex(va) if va is not None else "?"
            print(f"  file@{off:#08x}  vaddr={ui.cyan(va_s)}  {s!r}")

    fmt_sinks, fmt_srcs = P.format_string_candidates(t)

    # ---- one-gadget on libc ----
    if args.libc and os.path.exists(args.libc):
        og = P.one_gadgets(args.libc)
        if og:
            print(ui.section("one-gadget candidate sites (in libc)"))
            for addr, note in og:
                print(f"  {ui.cyan(hex(addr))}  {ui.grey(note)}")
            print(ui.grey("  tip: for exact constraints install the real `one_gadget` gem."))

    # ---- reverse hints ----
    rev = R.analyze(args.binary)
    rev_lines = []
    if rev["packer"]:
        rev_lines.append((ui.sev("high"), "Packer: " + ", ".join(rev["packer"])))
    if rev["likely_packed"]:
        rev_lines.append((ui.sev("med"), f"High entropy ({rev['entropy']}) — may be packed/encrypted"))
    for a in rev["antidbg"]:
        rev_lines.append((ui.sev("med"), a))
    if rev_lines:
        print(ui.section("Reverse-engineering flags"))
        for tag, msg in rev_lines:
            print(f"  {tag} {msg}")
    if rev["cmp_constants"]:
        print(ui.section("Frequent compare/arith constants (keygen hints)"))
        for val, cnt, hint in rev["cmp_constants"][:10]:
            print(f"  {ui.cyan(val):<12} ×{cnt:<3} {ui.grey(hint)}")

    # ---- static-binary analysis (syscalls / writable / write gadgets) ----
    static = None
    if args.static or t.prot.static:
        static = ST.analyze(args.binary)
        sys = static.get("syscalls", [])
        if sys:
            print(ui.section("Syscall sites (static binary)"))
            hot = [s for s in sys if s.get("hot")]
            for s in (hot or sys)[:14]:
                num = s["num"] if s["num"] is not None else "?"
                tag = ui.red(s["hot"]) if s.get("hot") else ui.grey(s["name"])
                print(f"  {ui.cyan(hex(s['addr']))}  rax={str(num):<4} {tag}")
            if hot:
                print(ui.grey(f"  ({len(sys)} syscall sites total; showing the useful ones)"))
        wr = static.get("writable", {})
        if wr.get("sections"):
            print(ui.section("Writable regions (stage your data here)"))
            for seg in wr.get("segments", []):
                flag = ui.red("RWX!") if seg["rwx"] else ui.grey(seg["perms"])
                print(ui.kv("segment", f"{hex(seg['vaddr'])}  size={hex(seg['size'])}  {flag}"))
            for s in wr["sections"]:
                print(ui.kv(s["name"], f"{hex(s['vaddr'])}  size={hex(s['size'])}"))
        wg = static.get("write_gadgets", [])
        if wg:
            print(ui.section("Write-what-where gadgets (write /bin/sh yourself)"))
            for a, insn in wg[:8]:
                print(f"  {ui.cyan(hex(a))}  {insn}")

    # ---- string xrefs ----
    if args.xref is not None:
        want = args.xref or None
        print(ui.section("String xrefs (find the code that uses a string)"))
        xrefs = ST.string_xrefs(args.binary, want_substr=want,
                                include_libc=args.xref_all)
        shown = [x for x in xrefs if x["xrefs"]][:args.max_strings]
        if shown:
            for e in shown:
                codes = ", ".join(ui.cyan(hex(a)) for a in e["xrefs"])
                disp = e["text"] if len(e["text"]) <= 50 else e["text"][:50] + "…"
                print(f"  str@{ui.grey(hex(e['str_addr']))} {disp!r}")
                print(f"       {ui.grey('used at:')} {codes}")
        else:
            print(ui.grey("  no referenced strings matched (try without a filter, or the "
                          "string may be built at runtime)"))

    # ---- heap analysis ----
    heap = None
    heap_imports = {"malloc", "calloc", "realloc", "free"} & set(t.imports)
    if args.heap or heap_imports:
        heap = H.analyze(args.binary, t.libc_version)
        if heap["uses_heap"]:
            print(ui.section("Heap analysis"))
            for fn, sites in heap["calls"].items():
                print(ui.kv(fn + " sites", ", ".join(sites[:8]) +
                            (" …" if len(sites) > 8 else "")))
            for s, msg, how in heap["smells"]:
                print(f"  {ui.sev(s)} {msg}")
                print(f"       {ui.grey(how)}")
            if heap["hints"]:
                print(ui.grey("  technique hints:"))
                for s, title, how in heap["hints"]:
                    print(f"    {ui.sev(s)} {ui.bold(title)}")
                    print(f"         {ui.grey(how)}")
            if args.heap and heap.get("snippets"):
                print(ui.grey("  helper snippets (also in --json):"))
                for name, _code in heap["snippets"]:
                    print(ui.grey(f"    • {name}"))

    # ---- auto ROP chain ----
    rop_result = None
    if args.ropchain:
        print(ui.section("Auto ROP chain"))
        rop_result = RC.build(args.binary, gadgets, args.libc)
        if rop_result["ok"]:
            print(f"  {ui.green('built:')} {rop_result['method']}")
            for line in rop_result["desc"].splitlines()[:14]:
                print("  " + ui.grey(line))
            print(ui.grey("  full chain + snippet in --json, or paste the snippet below:"))
            for line in rop_result["snippet"].splitlines():
                print("    " + line)
        else:
            print(f"  {ui.yellow('could not auto-build:')}")
            for line in rop_result["desc"].splitlines():
                print("  " + ui.grey(line))

    # ---- angr symbolic solve ----
    solve_result = None
    if args.solve_find or args.solve_addr:
        print(ui.section("Symbolic solve (angr)"))
        from . import solve_mod as SV
        find_addr = int(args.solve_addr, 16) if args.solve_addr else None
        print(ui.grey(f"  exploring (timeout {args.solve_timeout}s)…"))
        solve_result = SV.solve(
            args.binary, find=args.solve_find, find_addr=find_addr,
            avoid=args.solve_avoid, timeout=args.solve_timeout)
        if solve_result["ok"]:
            key = solve_result.get("pretty")
            print(f"  {ui.green('SOLVED →')} input = {ui.bold(key)}")
            if solve_result.get("stdin_clean") is not None:
                print(ui.grey("  (send this on stdin)"))
        else:
            print(f"  {ui.yellow('no solution:')} {solve_result['reason']}")
    if args.solve_script:
        from . import solve_mod as SV
        fa = int(args.solve_addr, 16) if args.solve_addr else None
        with open(args.solve_script, "w") as f:
            f.write(SV.emit_solver_script(args.binary, find=args.solve_find,
                                          find_addr=fa, avoid=args.solve_avoid))
        os.chmod(args.solve_script, 0o755)
        print(ui.grey(f"  angr solver script written: {args.solve_script}"))

    # ---- interesting strings ----
    if t.strings:
        print(ui.section(f"Interesting strings (top {args.max_strings})"))
        for off, s in t.strings[:args.max_strings]:
            disp = s if len(s) <= 90 else s[:90] + "…"
            print(f"  {ui.grey(f'{off:#08x}')}  {disp}")

    # ---- disasm a symbol on request ----
    if args.disasm:
        print(ui.section(f"Disassembly of {args.disasm}()"))
        for line in R.disasm_symbol(args.binary, args.disasm):
            print(line)

    # ---- attack plan ----
    steps = PLAN.build(t, gadgets, got, binsh, fmt_sinks, fmt_srcs, static=static)
    print(ui.header("SUGGESTED ATTACK PLAN"))
    for i, st in enumerate(steps, 1):
        pr = {1: ui.red("P1"), 2: ui.yellow("P2"), 3: ui.cyan("P3"), 4: ui.grey("P4")}.get(st["prio"], "P?")
        title = st["title"]
        print("\n" + ui.bold(f"{i}. [{pr}] {title}"))
        print(f"   {ui.grey('why :')} {st['why']}")
        print(f"   {ui.grey('how :')} {st['how']}")

    # ---- skeleton ----
    if args.skeleton:
        out = SK.generate(t, gadgets, got, binsh, args.skeleton)
        print(ui.section("Exploit skeleton"))
        print(f"  {ui.green('written:')} {out}")
        print(ui.grey("  edit the TODOs, then:  python3 " + os.path.basename(out) +
                      "   (add GDB=1 or REMOTE=1 as pwntools args)"))

    # ---- json ----
    if args.json:
        payload = {
            "binary": args.binary,
            "protections": t.prot.__dict__,
            "dangerous": t.dangerous,
            "win_funcs": [[n, a] for n, a in t.win_funcs],
            "gadgets": {k: [v[0], v[1]] for k, v in gadgets.items()},
            "got": {k: v for k, v in got.items()},
            "binsh": [[o, v, s] for (o, v, s) in binsh],
            "libc_version": t.libc_version,
            "reverse": rev,
            "plan": steps,
        }
        if heap is not None:
            payload["heap"] = heap
        if static is not None:
            payload["static"] = static
        if args.xref is not None:
            payload["xrefs"] = ST.string_xrefs(args.binary, want_substr=(args.xref or None),
                                               include_libc=args.xref_all)
        if rop_result is not None:
            payload["ropchain"] = rop_result
        if solve_result is not None:
            payload["solve"] = {k: (v.decode("latin-1") if isinstance(v, bytes) else v)
                                for k, v in solve_result.items()}
        with open(args.json, "w") as f:
            json.dump(payload, f, indent=2, default=str)
        print(ui.grey(f"\n  json written: {args.json}"))

    print()
    return 0


if __name__ == "__main__":
    sys.exit(main())
