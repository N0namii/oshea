"""Heap analysis: find alloc/free call sites, flag likely UAF / double-free patterns,
and give glibc-version-aware technique hints + pwntools helper snippets.

Static only (no execution). It points you at the right spots and technique; the
actual primitive you confirm in gdb (pwndbg/gef `heap`, `bins`)."""
import re

from elftools.elf.elffile import ELFFile
from elftools.elf.sections import SymbolTableSection


HEAP_FUNCS = ("malloc", "calloc", "realloc", "free", "reallocarray",
              "memalign", "posix_memalign", "aligned_alloc")


def _glibc_major_minor(ver):
    m = re.match(r"(\d+)\.(\d+)", ver or "")
    if not m:
        return None
    return int(m.group(1)), int(m.group(2))


def technique_hints(libc_version):
    """Return technique notes keyed to the glibc generation."""
    mm = _glibc_major_minor(libc_version)
    hints = []
    if mm is None:
        hints.append(("info", "libc version unknown",
                      "Identify it (strings | grep GLIBC, or the provided libc). The tcache "
                      "layout and which attacks work depend heavily on the exact version."))
        return hints
    major, minor = mm
    ver = f"{major}.{minor}"
    if (major, minor) >= (2, 26):
        hints.append(("high", f"glibc {ver}: tcache is active",
                      "tcache poisoning is usually the easiest win: free a chunk, overwrite its "
                      "fd (next) pointer to a target, malloc twice to get an arbitrary-address "
                      "chunk. Double-free into tcache also works."))
    if (major, minor) >= (2, 32):
        hints.append(("med", f"glibc {ver}: tcache fd is mangled (safe-linking)",
                      "fd = real_ptr XOR (chunk_addr >> 12). You must know/leak a heap address "
                      "to forge a valid fd. pwntools: encrypt with the same formula."))
    if (major, minor) >= (2, 34):
        hints.append(("med", f"glibc {ver}: __free_hook / __malloc_hook removed",
                      "Hook overwrite no longer works. Pivot to targets like _IO_FILE "
                      "(FSOP / house-of-* via stdout vtable), or overwrite a GOT/exit handler."))
    else:
        hints.append(("high", f"glibc {ver}: __free_hook / __malloc_hook available",
                      "Classic path: tcache-poison a chunk onto __free_hook, write system there, "
                      "free a chunk whose data is '/bin/sh'."))
    if (major, minor) < (2, 26):
        hints.append(("high", f"glibc {ver}: no tcache",
                      "fastbin dup / unsorted-bin attack territory. fastbin dup: double-free a "
                      "fastbin chunk, redirect fd (watch the size-field check)."))
    return hints


def _collect_calls_to(path, targets):
    """Disassemble .text and record addresses of `call <plt stub>` to heap funcs.
    Resolves PLT targets by relocation name. Returns dict func -> [call_site_addrs]."""
    try:
        from capstone import Cs, CS_ARCH_X86, CS_MODE_64, CS_MODE_32
    except Exception:
        return {}, {}
    from elftools.elf.relocation import RelocationSection

    with open(path, "rb") as f:
        elf = ELFFile(f)
        is64 = elf.elfclass == 64
        text = elf.get_section_by_name(".text")
        plt = elf.get_section_by_name(".plt")
        plt_sec = elf.get_section_by_name(".plt.sec")
        if text is None:
            return {}, {}

        # Build map: plt stub addr -> symbol name, via .rela.plt order
        plt_name = {}
        for sec in elf.iter_sections():
            if not isinstance(sec, RelocationSection):
                continue
            if "plt" not in sec.name:
                continue
            symtab = elf.get_section(sec["sh_link"])
            entry_size = 16
            stub_base = (plt_sec or plt)
            if stub_base is None:
                continue
            base = stub_base["sh_addr"]
            # .plt[0] is the resolver; stubs start at +16 for .plt, +0 for .plt.sec
            start_idx = 0 if plt_sec else 1
            for i, rel in enumerate(sec.iter_relocations()):
                try:
                    name = symtab.get_symbol(rel["r_info_sym"]).name
                except Exception:
                    name = ""
                stub = base + (i + start_idx) * entry_size
                if name:
                    plt_name[stub] = name

        md = Cs(CS_ARCH_X86, CS_MODE_64 if is64 else CS_MODE_32)
        code = text.data()
        calls = {}
        order = []  # (addr, func) in program order, for sequence analysis
        for ins in md.disasm(code, text["sh_addr"]):
            if ins.mnemonic == "call":
                m = re.match(r"^(0x[0-9a-fA-F]+)$", ins.op_str.strip())
                if m:
                    tgt = int(m.group(1), 16)
                    name = plt_name.get(tgt)
                    if name and name in targets:
                        calls.setdefault(name, []).append(ins.address)
                        order.append((ins.address, name))
        return calls, dict(order_list=order)


def analyze(path, libc_version=""):
    res = {"uses_heap": False, "calls": {}, "hints": [], "smells": [], "snippets": []}
    calls, extra = _collect_calls_to(path, set(HEAP_FUNCS))
    res["calls"] = {k: [hex(a) for a in v] for k, v in calls.items()}
    res["uses_heap"] = bool(calls)
    if not res["uses_heap"]:
        return res

    res["hints"] = technique_hints(libc_version)

    # crude smell detection from call ordering: free followed later by malloc of
    # similar cadence, or multiple frees — can't prove UAF statically, just flag.
    order = extra.get("order_list", [])
    names_seq = [n for _, n in order]
    free_count = names_seq.count("free")
    malloc_count = sum(names_seq.count(x) for x in ("malloc", "calloc", "realloc"))
    if free_count:
        res["smells"].append(
            ("med", f"{free_count} free() site(s), {malloc_count} alloc site(s)",
             "Check each free: is the pointer zeroed afterwards? If not → likely UAF. "
             "Can the same pointer be freed twice → double-free."))
    if free_count >= 2 and malloc_count:
        res["smells"].append(
            ("high", "multiple free() sites with reallocation",
             "Prime setup for double-free / tcache-dup. Trace whether a freed index can be "
             "freed again or still read/written via a dangling pointer."))

    res["snippets"] = _snippets(libc_version)
    return res


def _snippets(libc_version):
    mm = _glibc_major_minor(libc_version)
    safe_linking = mm is not None and mm >= (2, 32)
    out = []
    out.append(("tcache poison",
"""# tcache poisoning (adapt indices to the challenge's menu)
def enc(pos, ptr):            # safe-linking (glibc>=2.32); identity below if older
    return (pos >> 12) ^ ptr
# 1) alloc a, b ; free b ; free a    (a now points to b in tcache)
# 2) edit a's fd -> target     (use enc(heap_leak, target) if safe-linking)
# 3) malloc (gets a) ; malloc (gets chunk AT target)
"""))
    if not safe_linking and (mm is None or mm < (2, 34)):
        out.append(("__free_hook → system",
"""# classic free_hook overwrite (glibc < 2.34)
# tcache-poison a chunk onto libc.sym['__free_hook']
# write system there, then free a chunk containing b'/bin/sh\\x00'
# payload: edit(idx, p64(libc.sym['system']))
"""))
    return out
