"""Attack-plan engine: turn triage+pwn findings into a prioritized, human-readable
list of next steps. This is the 'what do I do now' brain — rule-based, explainable."""


def build(triage, gadgets, got, binsh, fmt_sinks, fmt_srcs, static=None):
    """Return a list of steps. Each step: dict(prio, title, why, how)."""
    steps = []
    p = triage.prot
    names = {n for n, *_ in triage.dangerous}
    imp = set(triage.imports)

    def add(prio, title, why, how):
        steps.append({"prio": prio, "title": title, "why": why, "how": how})

    # 1) Obvious win/backdoor function present
    if triage.win_funcs:
        wf = ", ".join(f"{n}@{hex(a)}" for n, a in triage.win_funcs[:5])
        add(1, "Redirect execution to the built-in win function",
            f"The binary already contains a target function ({wf}). "
            "Most 'ret2win' challenges just need you to overwrite the return address with it.",
            "Find the overflow offset (see stack-overflow step), then overwrite saved RIP "
            "with the win address. If it's non-PIE the address is fixed; if PIE you need a "
            "leak first. On amd64 remember a `ret` gadget may be needed for 16-byte stack "
            "alignment before calling into libc.")

    # 2) gets / scanf %s → stack overflow
    if "gets" in names or "__isoc99_scanf" in names or "scanf" in names or "read" in names:
        canary_note = ("A stack canary is present — you must leak it first (e.g. via a format "
                       "string or an over-read) and include it unchanged in your payload, or "
                       "find a path that doesn't cross the canary."
                       if p.canary else
                       "No stack canary — a straight overflow to saved RIP should work.")
        add(1 if not p.canary else 2, "Stack buffer overflow",
            "An unbounded input function is imported, so you can likely overflow a stack buffer.",
            "1) Send a cyclic pattern (de Bruijn) as input.\n"
            "       2) Observe the crash in gdb; read the faulting address (saved RIP).\n"
            "       3) Compute the offset with cyclic_find.\n"
            f"       4) {canary_note}")

    # 3) format string
    if fmt_sinks and (fmt_srcs or "%s" in str(triage.strings)):
        add(1, "Format-string vulnerability",
            f"printf-family sink(s) {fmt_sinks} are present alongside user input "
            f"{fmt_srcs or '(check manually)'} — if the user string reaches the format "
            "argument directly, you get arbitrary read AND write.",
            "1) Send `%p %p %p ...` to confirm you control the format and to leak stack "
            "(find your input's argument index).\n"
            "       2) Use `%<idx>$p` to leak PIE/libc/canary.\n"
            "       3) Use `%n`/`fmtstr_payload` (pwntools) to overwrite a GOT entry "
            "(e.g. point printf@GOT → system, or exit@GOT → main for another loop).")

    # 4) GOT overwrite viability
    if p.relro != "Full" and ("system" in imp or "printf" in imp or "puts" in imp):
        tgt = []
        for cand in ("printf", "puts", "exit", "__stack_chk_fail", "atoi", "strlen"):
            if cand in got:
                tgt.append(f"{cand}@GOT={hex(got[cand])}")
        add(2, "GOT overwrite (RELRO is " + p.relro + ")",
            "RELRO is not Full, so the GOT is writable at runtime. Overwriting a GOT entry "
            "that gets called with attacker-controlled args turns into code execution.",
            "Pick a function called after your write with a useful argument (classic: "
            "overwrite a GOT entry with system and trigger it with '/bin/sh' as the arg). "
            + (f"Candidate GOT targets: {', '.join(tgt)}." if tgt else ""))

    # 5) ret2libc / ret2system
    if not p.static and "system" not in triage.win_funcs and p.nx:
        has_rdi = any("pop rdi" in k for k in gadgets)
        binsh_here = [b for b in binsh if b[1] is not None]
        add(2, "ret2libc / ret2system",
            "NX is on (no shellcode on stack) and the binary is dynamically linked, so the "
            "standard path is to return into libc (system(\"/bin/sh\")).",
            ("You have a `pop rdi; ret` gadget — good. "
             if has_rdi else
             "You need a `pop rdi; ret` gadget to set the argument; search the binary and libc. ")
            + ("A '/bin/sh' string exists in the binary. "
               if binsh_here else
               "No '/bin/sh' in the binary — use the one inside libc (or write it via a gadget). ")
            + "Leak a libc address first (puts(puts@GOT) is the classic leak), resolve the "
              "libc base, then call system. Match the exact libc version to get offsets right.")

    # 6) shellcode if NX off
    if not p.nx:
        add(1, "Inject shellcode (NX is DISABLED)",
            "The stack/segment is executable, so you can jump to your own shellcode.",
            "Place shellcode in a known-address buffer (or jmp rsp / jmp esp gadget), "
            "overflow saved RIP to point at it. pwntools `asm(shellcraft.sh())` builds it.")

    # 7) PIE handling
    if p.pie:
        add(3, "Defeat PIE (need an address leak)",
            "The binary is PIE, so all its addresses are randomized at load. You can't use "
            "hardcoded addresses until you leak one.",
            "Leak any binary address (format string %p, an over-read, or an info-leak bug), "
            "subtract its known static offset to recover the image base, then add the base "
            "to every binary address you use.")

    # 8) heap
    if {"malloc", "free"} & imp:
        libc_note = ""
        if triage.libc_version:
            libc_note = (f" Detected glibc {triage.libc_version}: "
                         "run `--heap` for version-specific tcache/fastbin technique hints.")
        else:
            libc_note = (" Identify the glibc version (tcache vs older bins changes the "
                         "technique) — then `--heap` tailors the advice.")
        add(3 if {"malloc", "free"} & imp and "gets" not in names else 4,
            "Heap primitive likely",
            "malloc/free are used — the bug may be heap-based (UAF, double-free, overflow "
            "into chunk metadata).",
            "Map alloc/free sites (ctftool --heap does this), check whether freed pointers "
            "are zeroed (UAF) or can be freed twice (double-free)." + libc_note)

    # static-binary specific guidance (no imports to flag, so plain triage is blind)
    if p.static:
        sysnums = {s.get("num") for s in (static or {}).get("syscalls", [])}
        has_execve = 59 in sysnums or 322 in sysnums
        has_mprotect = 10 in sysnums
        if has_execve:
            add(2, "Static binary: build an execve syscall ROP chain",
                "This binary is statically linked (no libc to return into), but it already "
                "contains an execve syscall site and the pop gadgets to set up its arguments.",
                "Set rax=59, rdi=ptr to '/bin/sh', rsi=0, rdx=0, then hit a `syscall`. "
                "If the full '/bin/sh' string isn't in the binary, write it into a writable "
                "region (.bss/.data) first using a write-what-where gadget "
                "(ctftool --static lists both). `ctftool --ropchain` drafts the chain.")
        elif has_mprotect:
            add(2, "Static binary: mprotect + shellcode",
                "A mprotect syscall site exists — flip a page to RWX and jump to your shellcode.",
                "ROP: mprotect(addr, len, 7) then return into shellcode you placed in that "
                "region. Writable regions are listed by ctftool --static.")
        # stripped: tell them to use string xrefs to find logic
        if p.stripped:
            add(3, "Stripped: locate logic via string xrefs",
                "No symbols, so you can't jump to functions by name. But the binary's own "
                "error/prompt strings pin down where the interesting code is.",
                "Run `ctftool <bin> --xref` (or --xref SUBSTR). Each referenced string gives "
                "the code address that uses it — xref an error string (e.g. a parser's "
                "'malformed ...' message) to land directly in the routine to reverse.")

    # fallback
    if not steps:
        add(3, "No obvious memory-corruption primitive from static signs",
            "Static triage didn't flag a classic sink. The bug may be logical, or in how "
            "input is parsed.",
            "Open it in Ghidra/objdump, focus on the main input loop, look for integer "
            "handling, off-by-one, signedness, or an intended logic bypass. Run it and fuzz "
            "the inputs.")

    steps.sort(key=lambda s: s["prio"])
    return steps
