"""Pwn-focused analysis: ROP gadgets, PLT/GOT map, useful constant strings (/bin/sh),
format-string sinks, a built-in one-gadget scanner, and a cyclic-offset helper."""
import re
import subprocess
import shutil

from elftools.elf.elffile import ELFFile
from elftools.elf.relocation import RelocationSection


# A small curated set of gadget patterns that matter most for ROP on amd64/i386.
GADGET_WANTS = {
    "pop rdi ; ret": "set 1st arg (amd64)",
    "pop rsi ; ret": "set 2nd arg (amd64)",
    "pop rdx ; ret": "set 3rd arg (amd64)",
    "pop rax ; ret": "set syscall number (amd64)",
    "pop rsi ; pop r15 ; ret": "set 2nd arg (common libc)",
    "syscall": "raw syscall",
    "ret": "stack alignment / ret-slide",
    "leave ; ret": "stack pivot",
    "pop rbp ; ret": "set rbp / pivot",
    "pop rsp": "stack pivot",
    "int 0x80": "32-bit syscall",
    "pop eax ; ret": "set syscall number (i386)",
    "pop ebx ; ret": "set 1st arg (i386)",
    "pop ecx ; ret": "set 2nd arg (i386)",
    "pop edx ; ret": "set 3rd arg (i386)",
}


def _run_ropgadget(path):
    """Return list of (addr:int, insn:str). Uses ROPgadget CLI if present."""
    exe = shutil.which("ROPgadget")
    if not exe:
        return None
    try:
        out = subprocess.run(
            [exe, "--binary", path, "--nojop", "--nosys"],
            capture_output=True, text=True, timeout=120,
        ).stdout
    except Exception:
        return None
    gadgets = []
    for line in out.splitlines():
        m = re.match(r"^(0x[0-9a-fA-F]+)\s*:\s*(.+)$", line)
        if m:
            gadgets.append((int(m.group(1), 16), m.group(2).strip()))
    return gadgets


def find_key_gadgets(path):
    """Return dict: wanted-pattern -> (addr, full_insn) for the gadgets we care about."""
    gadgets = _run_ropgadget(path)
    found = {}
    if not gadgets:
        return found, (gadgets is not None)
    for addr, insn in gadgets:
        norm = insn.strip()
        for want in GADGET_WANTS:
            if want in found:
                continue
            # exact-ish: gadget string starts with the want, or equals it
            if norm == want or norm.startswith(want + " ;") or norm.startswith(want):
                found[want] = (addr, norm)
    return found, True


def plt_got(path):
    """Map PLT stubs and GOT entries by symbol name using relocations."""
    got = {}  # name -> got addr
    with open(path, "rb") as f:
        elf = ELFFile(f)
        for sec in elf.iter_sections():
            if not isinstance(sec, RelocationSection):
                continue
            symtab = elf.get_section(sec["sh_link"])
            for rel in sec.iter_relocations():
                try:
                    sym = symtab.get_symbol(rel["r_info_sym"])
                    name = sym.name
                except Exception:
                    name = ""
                if name:
                    got.setdefault(name, rel["r_offset"])
    return got


def bin_sh_addresses(path):
    """Offsets of '/bin/sh' and 'sh' constants embedded in the binary."""
    res = []
    with open(path, "rb") as f:
        raw = f.read()
    for needle in (b"/bin/sh\x00", b"/bin/sh", b"sh\x00"):
        start = 0
        while True:
            i = raw.find(needle, start)
            if i < 0:
                break
            res.append((i, needle.rstrip(b"\x00").decode()))
            start = i + 1
            if len(res) > 20:
                break
    # vaddr: map file offset -> vaddr via segments
    mapped = []
    with open(path, "rb") as f:
        elf = ELFFile(f)
        for off, s in res:
            va = None
            for seg in elf.iter_segments():
                if seg["p_type"] != "PT_LOAD":
                    continue
                fo, fsz, va0 = seg["p_offset"], seg["p_filesz"], seg["p_vaddr"]
                if fo <= off < fo + fsz:
                    va = va0 + (off - fo)
                    break
            mapped.append((off, va, s))
    return mapped


def format_string_candidates(triage):
    """Heuristic: printf-family imported AND a user-input source present."""
    imp = set(triage.imports)
    sinks = {"printf", "fprintf", "sprintf", "snprintf", "vprintf", "syslog", "dprintf"}
    srcs = {"scanf", "__isoc99_scanf", "fgets", "gets", "read", "fread", "recv"}
    has_sink = sorted(imp & sinks)
    has_src = sorted(imp & srcs)
    return has_sink, has_src


# ---- built-in one-gadget-style scanner over a libc (fallback for one_gadget) ----
def one_gadgets(libc_path, max_results=12):
    """Very small one-gadget finder: scan for 'lea rdi,[rip+x]; ...; call execve'-ish
    patterns by locating execve-adjacent code that sets /bin/sh. This is a *hint*
    generator, not a replacement for the real one_gadget; it flags candidate call
    sites to inspect in gdb."""
    try:
        from capstone import Cs, CS_ARCH_X86, CS_MODE_64
    except Exception:
        return []
    import io
    with open(libc_path, "rb") as f:
        raw = f.read()
    elf = ELFFile(io.BytesIO(raw))
    text = elf.get_section_by_name(".text")
    if text is None:
        return []
    code = text.data()
    base = text["sh_addr"]
    md = Cs(CS_ARCH_X86, CS_MODE_64)
    md.detail = False
    # find address of string "/bin/sh"
    binsh = raw.find(b"/bin/sh\x00")
    results = []
    # look for 'call execve' via PLT is hard in stripped libc; instead flag syscalls
    # preceded by mov eax, 0x3b (execve) — classic one-gadget constraint sites.
    insns = list(md.disasm(code, base))
    for i, ins in enumerate(insns):
        if ins.mnemonic == "syscall":
            # scan a few insns back for mov eax,0x3b
            for j in range(max(0, i - 8), i):
                if insns[j].mnemonic in ("mov",) and insns[j].op_str.replace(" ", "").startswith(("eax,0x3b", "rax,0x3b")):
                    results.append((ins.address, "execve syscall site (check rdi=/bin/sh, rsi,rdx=0)"))
                    break
        if len(results) >= max_results:
            break
    return results


def cyclic_pattern(length=200):
    """Return a de Bruijn-style cyclic pattern (pwntools-compatible) and a helper note."""
    try:
        from pwn import cyclic
        return cyclic(length)
    except Exception:
        # simple fallback
        import string
        alpha = (string.ascii_lowercase).encode()
        out = bytearray()
        n = 4
        # crude unique 4-grams
        import itertools
        for combo in itertools.product(alpha, repeat=n):
            out.extend(combo)
            if len(out) >= length:
                break
        return bytes(out[:length])
