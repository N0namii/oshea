"""Reverse-engineering helpers: packer/anti-debug hints, entropy, quick function
disassembly of a named symbol, and a comparison-constant extractor (great for
'find the password' style keygen challenges)."""
import math
import re

from elftools.elf.elffile import ELFFile


PACKER_SIGS = {
    b"UPX!": "UPX packed",
    b"$Info: This file is packed": "UPX packed",
    b".aspack": "ASPack",
    b".petite": "Petite",
    b"PECompact": "PECompact",
    b"MPRESS": "MPRESS",
}

ANTIDBG_SIGS = {
    "ptrace": "uses ptrace (classic anti-debug — patch it or set PTRACE return)",
    "PTRACE_TRACEME": "ptrace(TRACEME) anti-debug",
    "/proc/self/status": "reads TracerPid to detect debuggers",
    "IsDebuggerPresent": "Windows anti-debug",
    "getenv": "may check env (LD_PRELOAD / LINES etc.)",
    "alarm": "self-timeout (alarm) — may kill your session",
    "signal": "custom signal handling (may hide crashes)",
}


def entropy(data):
    if not data:
        return 0.0
    counts = [0] * 256
    for b in data:
        counts[b] += 1
    n = len(data)
    e = 0.0
    for c in counts:
        if c:
            pp = c / n
            e -= pp * math.log2(pp)
    return e


def analyze(path):
    with open(path, "rb") as f:
        raw = f.read()
    res = {"packer": [], "antidbg": [], "entropy": round(entropy(raw), 2),
           "likely_packed": False, "cmp_constants": []}
    for sig, label in PACKER_SIGS.items():
        if sig in raw:
            res["packer"].append(label)
    low = raw.lower()
    for sig, label in ANTIDBG_SIGS.items():
        if sig.lower().encode() in low:
            res["antidbg"].append(label)
    # high entropy with few packer hints → maybe packed/encrypted
    if res["entropy"] > 7.2 and raw[:4] == b"\x7fELF":
        res["likely_packed"] = True
    # pull immediate comparison constants from .text (cmp with imm) for keygen hints
    res["cmp_constants"] = _cmp_constants(raw)
    return res


def _cmp_constants(raw):
    """Disassemble .text and collect cmp/sub immediates — often password lengths,
    magic numbers, expected checksums."""
    try:
        from capstone import Cs, CS_ARCH_X86, CS_MODE_64, CS_MODE_32
    except Exception:
        return []
    import io
    if raw[:4] != b"\x7fELF":
        return []
    elf = ELFFile(io.BytesIO(raw))
    text = elf.get_section_by_name(".text")
    if text is None:
        return []
    mode = CS_MODE_64 if elf.elfclass == 64 else CS_MODE_32
    md = Cs(CS_ARCH_X86, mode)
    consts = {}
    for ins in md.disasm(text.data(), text["sh_addr"]):
        if ins.mnemonic in ("cmp", "sub", "xor", "add") and "0x" in ins.op_str:
            m = re.search(r"0x[0-9a-fA-F]+", ins.op_str)
            if m:
                val = int(m.group(0), 16)
                if 0x20 <= val <= 0x7fffffff and val not in (0xffffffff,):
                    consts.setdefault(val, 0)
                    consts[val] += 1
    # return most frequent interesting constants
    ranked = sorted(consts.items(), key=lambda kv: -kv[1])
    out = []
    for val, cnt in ranked[:15]:
        hint = ""
        if 0x20 <= val < 0x7f:
            hint = f"= '{chr(val)}'"
        elif val < 256:
            hint = "(small int — length/count?)"
        out.append((hex(val), cnt, hint))
    return out


def disasm_symbol(path, symname, max_insns=120):
    """Disassemble a named function. Returns list of 'addr  bytes  mnemonic op'."""
    try:
        from capstone import Cs, CS_ARCH_X86, CS_MODE_64, CS_MODE_32
    except Exception:
        return ["(capstone not available)"]
    with open(path, "rb") as f:
        elf = ELFFile(f)
        addr = size = None
        for sec in elf.iter_sections():
            from elftools.elf.sections import SymbolTableSection
            if isinstance(sec, SymbolTableSection):
                for sym in sec.iter_symbols():
                    if sym.name == symname and sym["st_value"]:
                        addr = sym["st_value"]
                        size = sym["st_size"] or max_insns * 15
                        break
            if addr:
                break
        if addr is None:
            return [f"(symbol {symname!r} not found — binary may be stripped)"]
        # locate the file bytes
        data = None
        for seg in elf.iter_segments():
            if seg["p_type"] != "PT_LOAD":
                continue
            va, fo, fsz = seg["p_vaddr"], seg["p_offset"], seg["p_filesz"]
            if va <= addr < va + fsz:
                off = fo + (addr - va)
                f.seek(off)
                data = f.read(min(size, fsz))
                break
        if data is None:
            return ["(could not map symbol to file bytes)"]
        mode = CS_MODE_64 if elf.elfclass == 64 else CS_MODE_32
        md = Cs(CS_ARCH_X86, mode)
        out = []
        for i, ins in enumerate(md.disasm(data, addr)):
            out.append(f"  {ins.address:#x}:  {ins.mnemonic:<7} {ins.op_str}")
            if i + 1 >= max_insns:
                break
        return out or ["(no instructions decoded)"]
