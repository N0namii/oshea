"""Symbolic solver for simple reverse/keygen challenges, powered by angr.

Give it a binary and either:
  - a success string the program prints on correct input (--solve-find "Correct"), or
  - a target address to reach (--solve-addr 0x...), optionally addresses to avoid.

It searches for stdin (or an argv) that drives execution there and prints the input.

Honest scope: this cracks the *easy-to-medium* rev tasks (linear checks, simple
transforms, xor/sum constraints). It will struggle or blow up on heavy loops,
strong hashing/crypto, or huge state spaces — that's expected; fall back to manual
RE for those. A timeout keeps it from hanging your session."""
import logging


def _quiet():
    for name in ("angr", "cle", "pyvex", "claripy", "angr.engines",
                 "angr.sim_manager", "angr.project"):
        logging.getLogger(name).setLevel(logging.ERROR)


def solve(path, find=None, find_addr=None, avoid=None, avoid_addrs=None,
          stdin_len=None, argv_lens=None, timeout=180):
    """Return dict with the discovered input or a reason it failed.

    find        : substring (str/bytes) that appears on stdout for success
    find_addr   : int address to reach
    avoid       : substring that marks failure (pruned)
    avoid_addrs : list[int] addresses to prune
    stdin_len   : if set, constrain symbolic stdin to this many bytes
    argv_lens   : list[int] -> make argv[1..] symbolic with these lengths
    """
    try:
        import angr
    except Exception as e:
        return {"ok": False, "reason": f"angr not installed: {e}"}
    _quiet()

    import signal

    class _TO(Exception):
        pass

    def _alarm(signum, frame):
        raise _TO()

    if isinstance(find, str):
        find = find.encode()
    if isinstance(avoid, str):
        avoid = avoid.encode()

    try:
        proj = angr.Project(path, auto_load_libs=False)
    except Exception as e:
        return {"ok": False, "reason": f"could not load binary: {e}"}

    # Build the entry state. Symbolic argv if requested, else symbolic stdin.
    # angr 10 vendors claripy; reach BVS through the state's own solver.
    sym_argv = []
    if argv_lens:
        state = proj.factory.full_init_state(args=[path])  # temp to get a solver
        for i, ln in enumerate(argv_lens):
            sym_argv.append(state.solver.BVS(f"argv{i+1}", ln * 8))
        state = proj.factory.full_init_state(args=[path] + sym_argv)
    else:
        state = proj.factory.full_init_state(stdin=angr.SimFileStream)

    simgr = proj.factory.simulation_manager(state)

    # find / avoid predicates
    def _find(s):
        if find is not None and find in s.posix.dumps(1):
            return True
        return False

    def _avoid(s):
        if avoid is not None and avoid in s.posix.dumps(1):
            return True
        return False

    find_arg = None
    avoid_arg = None
    if find_addr is not None:
        find_arg = find_addr
    elif find is not None:
        find_arg = _find
    else:
        return {"ok": False, "reason": "need a success string (find) or target address (find_addr)"}

    if avoid_addrs:
        avoid_arg = avoid_addrs
    elif avoid is not None:
        avoid_arg = _avoid

    signal.signal(signal.SIGALRM, _alarm)
    signal.alarm(int(timeout))
    try:
        if avoid_arg is not None:
            simgr.explore(find=find_arg, avoid=avoid_arg)
        else:
            simgr.explore(find=find_arg)
    except _TO:
        return {"ok": False, "reason": f"timed out after {timeout}s — too complex for quick symbolic solve"}
    except Exception as e:
        return {"ok": False, "reason": f"angr error during exploration: {e}"}
    finally:
        signal.alarm(0)

    if not simgr.found:
        return {"ok": False, "reason": "no satisfying input found (check your find/avoid, or it's too hard)"}

    found = simgr.found[0]
    result = {"ok": True}
    if argv_lens:
        vals = []
        for chunk in sym_argv:
            vals.append(found.solver.eval(chunk, cast_to=bytes))
        result["argv"] = [v for v in vals]
        result["pretty"] = " ".join(
            repr(v.split(b"\x00")[0]) for v in vals)
    else:
        raw = found.posix.dumps(0)
        trimmed = raw.split(b"\x00")[0] if b"\x00" in raw else raw.rstrip(b"\x00")
        result["stdin"] = raw
        result["stdin_clean"] = trimmed
        result["pretty"] = repr(trimmed)
    return result


def emit_solver_script(path, find=None, find_addr=None, avoid=None):
    """Produce a standalone angr script the user can keep and tweak."""
    import os
    b = os.path.basename(path)
    find_line = (f"state_find = lambda s: {find!r}.encode() in s.posix.dumps(1)"
                 if find else f"state_find = {hex(find_addr)}" if find_addr else
                 "state_find = lambda s: b'Correct' in s.posix.dumps(1)")
    avoid_line = (f"state_avoid = lambda s: {avoid!r}.encode() in s.posix.dumps(1)"
                  if avoid else "state_avoid = lambda s: b'Wrong' in s.posix.dumps(1)")
    return f"""#!/usr/bin/env python3
# Standalone angr solver (generated by ctftool). Tweak find/avoid as needed.
import angr, logging
logging.getLogger('angr').setLevel('ERROR')

proj = angr.Project({b!r}, auto_load_libs=False)
state = proj.factory.full_init_state(stdin=angr.SimFileStream)
simgr = proj.factory.simulation_manager(state)

{find_line}
{avoid_line}
simgr.explore(find=state_find, avoid=state_avoid)

if simgr.found:
    inp = simgr.found[0].posix.dumps(0)
    print("INPUT:", inp.split(b'\\x00')[0])
else:
    print("no solution — adjust find/avoid, lengthen stdin, or solve manually")
"""
