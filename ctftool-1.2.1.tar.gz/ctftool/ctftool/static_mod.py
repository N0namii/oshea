"""Static-binary & stripped-binary helpers — the pieces that plain import-based
triage misses on statically-linked / stripped targets.

  * string_xrefs  : map interesting strings -> code addresses that reference them
                    (how you locate a parser in a stripped binary: xref the error
                    string it prints).
  * syscall_sites : find `syscall` instructions and infer the syscall number from a
                    preceding `mov eax/rax, imm` — fills the "no sinks detected" gap
                    on static binaries (no PLT imports to flag).
  * writable_regions : writable segments/sections (.bss/.data) where you can stage
                    data such as a "/bin/sh" string you write yourself.
  * write_gadgets : `mov [reg], reg ; ret` write-what-where gadgets for that staging.

All capstone + pyelftools, no execution, no network."""
import re

from elftools.elf.elffile import ELFFile


# ---- minimal x86-64 syscall table (the ones that matter for exploitation) ----
SYSCALLS_X64 = {
    0: "read", 1: "write", 2: "open", 3: "close", 9: "mmap", 10: "mprotect",
    11: "munmap", 12: "brk", 22: "pipe", 32: "dup", 33: "dup2", 39: "getpid",
    41: "socket", 42: "connect", 43: "accept", 49: "bind", 50: "listen",
    57: "fork", 59: "execve", 60: "exit", 62: "kill", 85: "creat",
    101: "ptrace", 105: "setuid", 106: "setgid", 257: "openat", 322: "execveat",
}
# syscalls especially juicy for a shell / escalation
HOT_SYSCALLS = {59: "execve → shell!", 322: "execveat → shell!",
                10: "mprotect → make RWX for shellcode", 9: "mmap → RWX region",
                2: "open", 257: "openat", 0: "read", 1: "write",
                105: "setuid", 101: "ptrace (anti-debug)"}

# syscalls table for i386 (int 0x80) — a few essentials
SYSCALLS_X86 = {1: "exit", 3: "read", 4: "write", 5: "open", 11: "execve",
                125: "mprotect", 192: "mmap2"}


def _text_section(elf):
    return elf.get_section_by_name(".text")


def _string_sections(elf):
    """Yield (name, vaddr, data) for sections that typically hold strings."""
    for name in (".rodata", ".data", ".rdata", ".data.rel.ro"):
        sec = elf.get_section_by_name(name)
        if sec is not None and sec["sh_addr"]:
            yield name, sec["sh_addr"], sec.data()


def interesting_string_vaddrs(path, pattern=None, minlen=4, limit=400):
    """Return list of (vaddr, text) from rodata/data, optionally filtered by regex."""
    rx = re.compile(pattern) if pattern else None
    out = []
    with open(path, "rb") as f:
        elf = ELFFile(f)
        for _name, base, data in _string_sections(elf):
            cur = bytearray()
            start = 0
            for i, b in enumerate(data):
                if 0x20 <= b < 0x7f:
                    if not cur:
                        start = i
                    cur.append(b)
                else:
                    if len(cur) >= minlen:
                        s = cur.decode("latin-1")
                        if rx is None or rx.search(s):
                            out.append((base + start, s))
                    cur = bytearray()
            if len(cur) >= minlen:
                s = cur.decode("latin-1")
                if rx is None or rx.search(s):
                    out.append((base + start, s))
            if len(out) >= limit:
                break
    return out[:limit]


# Strings that belong to the statically-linked libc / toolchain, not the
# challenge itself. On a static binary these dominate and bury the app's own
# strings, so we deprioritize them unless the user explicitly filters for them.
_LIBC_NOISE = re.compile(
    r"(\.c$|\.h$|__|glibc|malloc|realloc|calloc|memalign|tcache|GCONV|GLIBC|"
    r"printf_positional|vfprintf|fwide|_IO_|wcsrtombs|mbsrtowcs|sysdeps|"
    r"assert|INT_MAX|size_t|__libc|outstring|to_outpunct|heap_trim|mtrim|"
    r"sysmalloc|mremap|cxa_atexit|futex|dl-|ld\.so|POSIX$|\(nil\)|\(null\))",
    re.IGNORECASE,
)


def _is_noise(s):
    return bool(_LIBC_NOISE.search(s))


def string_xrefs(path, want_substr=None, max_results=60, include_libc=False):
    """For each interesting string, find code addresses that reference it.

    Returns list of dicts: {str_addr, text, xrefs:[code_addr,...]}.
    Handles rip-relative (`lea reg,[rip+d]`) and absolute-immediate references
    (common in non-PIE binaries).

    On static binaries the linked-in libc contributes a lot of internal strings;
    by default those are deprioritized so the challenge's own strings surface.
    Set include_libc=True (or pass want_substr) to see everything."""
    try:
        from capstone import Cs, CS_ARCH_X86, CS_MODE_64, CS_MODE_32
    except Exception:
        return []
    with open(path, "rb") as f:
        elf = ELFFile(f)
        text = _text_section(elf)
        if text is None:
            return []
        is64 = elf.elfclass == 64
        # collect candidate string vaddrs
        strings = interesting_string_vaddrs(path)
        if want_substr:
            strings = [(a, s) for (a, s) in strings if want_substr.lower() in s.lower()]
        straddr = {a: s for a, s in strings}
        if not straddr:
            return []
        lo, hi = min(straddr), max(straddr)

        md = Cs(CS_ARCH_X86, CS_MODE_64 if is64 else CS_MODE_32)
        md.detail = False
        code = text.data()
        base = text["sh_addr"]
        xref = {a: [] for a in straddr}

        for ins in md.disasm(code, base):
            op = ins.op_str
            target = None
            # rip-relative: "..., [rip + 0x1234]" or "- 0x.."
            m = re.search(r"\[rip ([+\-]) (0x[0-9a-fA-F]+)\]", op)
            if m:
                disp = int(m.group(2), 16)
                if m.group(1) == "-":
                    disp = -disp
                target = ins.address + ins.size + disp
            else:
                # absolute immediate anywhere in operand that lands in string range
                for im in re.findall(r"0x[0-9a-fA-F]+", op):
                    v = int(im, 16)
                    if lo <= v <= hi and v in straddr:
                        target = v
                        break
            if target is not None and target in xref:
                if ins.address not in xref[target]:
                    xref[target].append(ins.address)

        results = []
        for a, s in strings:
            if xref.get(a):
                results.append({"str_addr": a, "text": s, "xrefs": xref[a][:6],
                                "noise": _is_noise(s)})
        # Rank: application strings first (not libc noise), then by how specific
        # they are (fewer xrefs = more likely a unique app message, not a shared
        # libc assert). The user filtering by substring overrides this.
        filtering = bool(want_substr)
        if not include_libc and not filtering:
            app = [r for r in results if not r["noise"]]
            noise = [r for r in results if r["noise"]]
            app.sort(key=lambda r: len(r["xrefs"]))      # unique app msgs first
            noise.sort(key=lambda r: -len(r["xrefs"]))
            results = app + noise
        else:
            results.sort(key=lambda r: (0 if r["xrefs"] else 1, -len(r["xrefs"])))
        return results[:max_results]


def syscall_sites(path, max_results=40):
    """Find syscall/int0x80 instructions and infer the syscall number from a nearby
    preceding `mov eax/rax, imm`. Returns list of dicts."""
    try:
        from capstone import Cs, CS_ARCH_X86, CS_MODE_64, CS_MODE_32
    except Exception:
        return []
    with open(path, "rb") as f:
        elf = ELFFile(f)
        text = _text_section(elf)
        if text is None:
            return []
        is64 = elf.elfclass == 64
        md = Cs(CS_ARCH_X86, CS_MODE_64 if is64 else CS_MODE_32)
        md.detail = False
        insns = list(md.disasm(text.data(), text["sh_addr"]))
        table = SYSCALLS_X64 if is64 else SYSCALLS_X86
        reg = "eax" if is64 else "eax"
        out = []
        for i, ins in enumerate(insns):
            is_sys = (ins.mnemonic == "syscall") or \
                     (ins.mnemonic == "int" and ins.op_str.strip() in ("0x80",))
            if not is_sys:
                continue
            num = None
            # look back up to 12 insns for mov eax/rax, imm
            for j in range(i - 1, max(-1, i - 13), -1):
                mn, ops = insns[j].mnemonic, insns[j].op_str.replace(" ", "")
                m = re.match(r"(eax|rax),(0x[0-9a-fA-F]+|\d+)$", ops)
                if mn == "mov" and m:
                    num = int(m.group(2), 16) if m.group(2).startswith("0x") else int(m.group(2))
                    break
                # xor eax,eax => 0
                if mn == "xor" and ops in ("eax,eax", "rax,rax"):
                    num = 0
                    break
            name = table.get(num, "?") if num is not None else "?"
            hot = HOT_SYSCALLS.get(num)
            out.append({"addr": ins.address, "num": num, "name": name, "hot": hot})
            if len(out) >= max_results:
                break
        return out


def writable_regions(path):
    """Return writable PT_LOAD segments and notable writable sections (.bss/.data)."""
    regions = []
    sections = []
    with open(path, "rb") as f:
        elf = ELFFile(f)
        for seg in elf.iter_segments():
            if seg["p_type"] != "PT_LOAD":
                continue
            flags = seg["p_flags"]
            if flags & 0x2:  # W
                rwx = ("r" if flags & 4 else "-") + ("w" if flags & 2 else "-") + \
                      ("x" if flags & 1 else "-")
                regions.append({"vaddr": seg["p_vaddr"], "size": seg["p_memsz"],
                                "perms": rwx, "rwx": bool(flags & 1)})
        for name in (".bss", ".data", ".got", ".got.plt", ".data.rel.ro"):
            sec = elf.get_section_by_name(name)
            if sec is not None and sec["sh_addr"]:
                sections.append({"name": name, "vaddr": sec["sh_addr"],
                                 "size": sec["sh_size"]})
    return {"segments": regions, "sections": sections}


def write_gadgets(path, max_results=12):
    """Find write-what-where gadgets: `mov [reg], reg ; ret` (and qword variants).
    Needs ROPgadget. Returns list of (addr, insn)."""
    import shutil
    import subprocess
    exe = shutil.which("ROPgadget")
    if not exe:
        return []
    try:
        out = subprocess.run([exe, "--binary", path, "--nojop"],
                             capture_output=True, text=True, timeout=120).stdout
    except Exception:
        return []
    res = []
    pat = re.compile(r"^(0x[0-9a-fA-F]+)\s*:\s*(mov (qword |dword )?ptr \[[a-z0-9]+\], [a-z0-9]+ ; ret)$")
    for line in out.splitlines():
        m = pat.match(line.strip())
        if m:
            res.append((int(m.group(1), 16), m.group(2)))
            if len(res) >= max_results:
                break
    return res


def analyze(path):
    """Bundle the static-oriented analyses into one dict for the report/JSON."""
    res = {}
    try:
        res["syscalls"] = syscall_sites(path)
    except Exception as e:
        res["syscalls"] = []
    try:
        res["writable"] = writable_regions(path)
    except Exception:
        res["writable"] = {"segments": [], "sections": []}
    try:
        res["write_gadgets"] = write_gadgets(path)
    except Exception:
        res["write_gadgets"] = []
    return res
