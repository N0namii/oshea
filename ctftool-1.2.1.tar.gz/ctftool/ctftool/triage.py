"""Core triage: file identity, protections (checksec-equivalent), symbols/imports,
dangerous functions, interesting strings. Pure pyelftools + heuristics, no network."""
import re
import struct
from dataclasses import dataclass, field

from elftools.elf.elffile import ELFFile
from elftools.elf.dynamic import DynamicSection
from elftools.elf.sections import SymbolTableSection
from elftools.elf.gnuversions import GNUVerNeedSection


# Functions that are classic sources of memory-corruption / logic bugs in CTF.
# category -> (severity, short why)
DANGEROUS = {
    # unbounded / overflow-prone
    "gets":      ("crit", "no bounds check → trivial stack overflow"),
    "strcpy":    ("high", "no bounds check on dst"),
    "strcat":    ("high", "no bounds check on dst"),
    "sprintf":   ("high", "unbounded write into buffer"),
    "vsprintf":  ("high", "unbounded write into buffer"),
    "scanf":     ("high", "%s without width → overflow"),
    "__isoc99_scanf": ("high", "%s without width → overflow"),
    "sscanf":    ("med",  "%s without width → overflow"),
    "realpath":  ("med",  "classic PATH_MAX overflow"),
    "getwd":     ("high", "no bounds check"),
    # format string
    "printf":    ("med",  "format string if arg is user-controlled"),
    "fprintf":   ("med",  "format string if arg is user-controlled"),
    "snprintf":  ("low",  "format string if fmt is user-controlled"),
    "syslog":    ("med",  "format string sink"),
    # command / code exec sinks (great for 'win' paths)
    "system":    ("high", "command execution sink — ROP/GOT target"),
    "execve":    ("high", "exec sink"),
    "execl":     ("high", "exec sink"),
    "execlp":    ("high", "exec sink"),
    "popen":     ("high", "command execution sink"),
    # heap
    "malloc":    ("info", "heap present — watch for UAF/overflow"),
    "free":      ("info", "heap present — watch for double-free/UAF"),
    "realloc":   ("info", "heap present"),
    # misc dangerous
    "memcpy":    ("low",  "overflow if size user-controlled"),
    "read":      ("low",  "overflow if length > buffer"),
    "alloca":    ("med",  "stack pointer moved by user size"),
    "mmap":      ("info", "may create RWX region (shellcode)"),
    "mprotect":  ("med",  "may flip page to RWX (shellcode target)"),
    "strncpy":   ("info", "may leave dst non-terminated"),
}

# Function names that frequently mark an intended 'win'/backdoor path.
WIN_HINTS = ("win", "shell", "backdoor", "flag", "admin", "secret", "giveshell",
             "get_flag", "getflag", "cat_flag", "print_flag", "magic",
             "spawn", "giveflag", "bin_sh")

INTERESTING_STRING_RE = re.compile(
    r"(/bin/sh|/bin/bash|sh\x00|flag\{|FLAG\{|\.so\b|libc|%[0-9]*\$?[sxpn]|"
    r"/flag|cat |system|/etc/passwd|GLIBC_|password|passwd|admin|secret|token|key)",
    re.IGNORECASE,
)


@dataclass
class Protections:
    arch: str = "?"
    bits: int = 0
    endian: str = "little"
    pie: bool = False
    pie_known: bool = True
    relro: str = "No"          # No / Partial / Full
    canary: bool = False
    nx: bool = True
    rpath: list = field(default_factory=list)
    runpath: list = field(default_factory=list)
    fortify: bool = False
    static: bool = False
    stripped: bool = True


@dataclass
class Triage:
    path: str
    filetype: str = ""
    prot: Protections = field(default_factory=Protections)
    imports: list = field(default_factory=list)       # dynamic symbols referenced
    exports: list = field(default_factory=list)       # defined funcs (name, addr)
    dangerous: list = field(default_factory=list)      # (name, severity, why)
    win_funcs: list = field(default_factory=list)       # (name, addr)
    strings: list = field(default_factory=list)         # (offset, text)
    libc_version: str = ""
    base_hint: int = 0


def _detect_arch(elf):
    m = elf.header["e_machine"]
    bits = 64 if elf.elfclass == 64 else 32
    endian = "little" if elf.little_endian else "big"
    arch = {
        "EM_X86_64": "amd64", "EM_386": "i386",
        "EM_AARCH64": "aarch64", "EM_ARM": "arm",
        "EM_MIPS": "mips", "EM_RISCV": "riscv",
        "EM_PPC": "powerpc", "EM_PPC64": "powerpc64",
    }.get(m, str(m))
    return arch, bits, endian


def _protections(elf, raw):
    p = Protections()
    p.arch, p.bits, p.endian = _detect_arch(elf)
    p.static = True
    p.pie = elf.header["e_type"] == "ET_DYN"
    # NX: look for a GNU_STACK segment that is executable
    p.nx = True
    gnu_relro = False
    bind_now = False
    for seg in elf.iter_segments():
        t = seg["p_type"]
        if t == "PT_GNU_STACK":
            p.nx = not bool(seg["p_flags"] & 0x1)  # X bit
        elif t == "PT_GNU_RELRO":
            gnu_relro = True
        elif t in ("PT_INTERP", "PT_DYNAMIC"):
            p.static = False

    # dynamic section flags for RELRO / rpath / bind now
    dyn = None
    for sec in elf.iter_sections():
        if isinstance(sec, DynamicSection):
            dyn = sec
            break
    if dyn is not None:
        p.static = False
        for tag in dyn.iter_tags():
            if tag.entry.d_tag == "DT_FLAGS" and (tag.entry.d_val & 0x8):
                bind_now = True
            if tag.entry.d_tag == "DT_FLAGS_1" and (tag.entry.d_val & 0x1):
                bind_now = True
            if tag.entry.d_tag == "DT_BIND_NOW":
                bind_now = True
            if tag.entry.d_tag == "DT_RPATH":
                p.rpath.append(getattr(tag, "rpath", "?"))
            if tag.entry.d_tag == "DT_RUNPATH":
                p.runpath.append(getattr(tag, "runpath", "?"))

    if gnu_relro and bind_now:
        p.relro = "Full"
    elif gnu_relro:
        p.relro = "Partial"
    else:
        p.relro = "No"

    # stripped? check for symtab
    p.stripped = elf.get_section_by_name(".symtab") is None
    return p


def _iter_symbols(elf):
    for sec in elf.iter_sections():
        if isinstance(sec, SymbolTableSection):
            for sym in sec.iter_symbols():
                yield sym


def _collect_symbols(elf):
    imports, exports, canary, fortify = [], [], False, False
    for sym in _iter_symbols(elf):
        name = sym.name
        if not name:
            continue
        info_type = sym["st_info"]["type"]
        shndx = sym["st_shndx"]
        if name == "__stack_chk_fail":
            canary = True
        if name.endswith("_chk"):
            fortify = True
        if shndx == "SHN_UNDEF":
            imports.append(name)
        elif info_type == "STT_FUNC" and sym["st_value"]:
            exports.append((name, sym["st_value"]))
    # dedupe preserving order
    imports = list(dict.fromkeys(imports))
    return imports, exports, canary, fortify


def _libc_version(raw):
    m = re.search(rb"GNU C Library[^\n]*?(\d+\.\d+)", raw)
    if m:
        return m.group(1).decode()
    m = re.search(rb"glibc[ -]?(\d+\.\d+)", raw)
    if m:
        return m.group(1).decode()
    return ""


def _extract_strings(raw, minlen=4, limit=4000):
    out = []
    cur = bytearray()
    start = 0
    for i, b in enumerate(raw):
        if 0x20 <= b < 0x7f:
            if not cur:
                start = i
            cur.append(b)
        else:
            if len(cur) >= minlen:
                out.append((start, cur.decode("latin-1")))
            cur = bytearray()
        if len(out) >= limit:
            break
    if len(cur) >= minlen:
        out.append((start, cur.decode("latin-1")))
    return out


def run(path):
    with open(path, "rb") as f:
        raw = f.read()
    t = Triage(path=path)

    # magic / file type
    if raw[:4] == b"\x7fELF":
        t.filetype = "ELF"
    elif raw[:2] == b"MZ":
        t.filetype = "PE (Windows)"
    else:
        t.filetype = "unknown (not ELF)"

    if t.filetype != "ELF":
        # still give strings so rev folks aren't blind
        t.strings = [s for s in _extract_strings(raw) if INTERESTING_STRING_RE.search(s[1])][:200]
        return t

    import io
    elf = ELFFile(io.BytesIO(raw))
    t.prot = _protections(elf, raw)
    t.imports, t.exports, canary, fortify = _collect_symbols(elf)
    t.prot.canary = canary
    t.prot.fortify = fortify
    t.libc_version = _libc_version(raw)
    if not t.prot.pie:
        # non-PIE: common default base
        t.base_hint = min((a for _, a in t.exports if a), default=0x400000)

    # dangerous functions among imports + exports
    all_names = set(t.imports) | {n for n, _ in t.exports}
    seen = set()
    for name in all_names:
        base = name.replace("__isoc99_", "")
        key = name if name in DANGEROUS else (base if base in DANGEROUS else None)
        if key and name not in seen:
            seen.add(name)
            s, why = DANGEROUS[key]
            t.dangerous.append((name, s, why))
    # sort by severity
    order = {"crit": 0, "high": 1, "med": 2, "low": 3, "info": 4}
    t.dangerous.sort(key=lambda x: order.get(x[1], 9))

    # win / backdoor functions
    for name, addr in t.exports:
        low = name.lower()
        if any(h == low or h in low for h in WIN_HINTS):
            # avoid matching e.g. 'flush' via 'sh' — require word-ish
            if low == "bin_sh" or re.search(r"(^|_)(win|shell|backdoor|flag|admin|secret|magic|spawn|giveshell|getflag|get_flag|print_flag|cat_flag|giveflag)", low):
                t.win_funcs.append((name, addr))

    # interesting strings
    t.strings = [(o, s) for (o, s) in _extract_strings(raw)
                 if INTERESTING_STRING_RE.search(s)][:300]
    return t
