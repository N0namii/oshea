"""Terminal formatting helpers: colors, boxes, severity tags. Degrades to plain text."""
import os
import sys

_NO_COLOR = (not sys.stdout.isatty()) or os.environ.get("NO_COLOR") is not None


class C:
    RESET = "" if _NO_COLOR else "\033[0m"
    BOLD = "" if _NO_COLOR else "\033[1m"
    DIM = "" if _NO_COLOR else "\033[2m"
    RED = "" if _NO_COLOR else "\033[31m"
    GREEN = "" if _NO_COLOR else "\033[32m"
    YELLOW = "" if _NO_COLOR else "\033[33m"
    BLUE = "" if _NO_COLOR else "\033[34m"
    MAGENTA = "" if _NO_COLOR else "\033[35m"
    CYAN = "" if _NO_COLOR else "\033[36m"
    GREY = "" if _NO_COLOR else "\033[90m"


def bold(s):    return f"{C.BOLD}{s}{C.RESET}"
def red(s):     return f"{C.RED}{s}{C.RESET}"
def green(s):   return f"{C.GREEN}{s}{C.RESET}"
def yellow(s):  return f"{C.YELLOW}{s}{C.RESET}"
def blue(s):    return f"{C.BLUE}{s}{C.RESET}"
def cyan(s):    return f"{C.CYAN}{s}{C.RESET}"
def grey(s):    return f"{C.GREY}{s}{C.RESET}"
def magenta(s): return f"{C.MAGENTA}{s}{C.RESET}"


def header(title):
    line = "═" * (len(title) + 2)
    return f"\n{C.CYAN}╔{line}╗\n║ {C.BOLD}{title}{C.RESET}{C.CYAN} ║\n╚{line}╝{C.RESET}"


def section(title):
    return f"\n{C.BOLD}{C.BLUE}▸ {title}{C.RESET}"


# severity → colored tag
_SEV = {
    "crit": lambda: red(bold("[CRITICAL]")),
    "high": lambda: red("[HIGH]"),
    "med":  lambda: yellow("[MED] "),
    "low":  lambda: cyan("[LOW] "),
    "info": lambda: grey("[INFO]"),
    "good": lambda: green("[OK]  "),
}


def sev(level):
    return _SEV.get(level, _SEV["info"])()


def kv(key, value, width=22):
    return f"  {C.GREY}{key:<{width}}{C.RESET} {value}"
