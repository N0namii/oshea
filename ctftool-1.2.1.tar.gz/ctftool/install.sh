#!/usr/bin/env bash
# Install ctftool's Python dependencies. No network calls beyond pip.
set -e
echo "[*] Installing ctftool dependencies..."

PIP="pip3"
command -v pip3 >/dev/null 2>&1 || PIP="python3 -m pip"

# core engines the toolkit orchestrates
$PIP install --upgrade pyelftools capstone pwntools ROPgadget 2>&1 | tail -2 || {
  echo "[!] pip failed; try: $PIP install --break-system-packages pyelftools capstone pwntools ROPgadget"
}

echo "[*] Optional extras:"
echo "      pip install angr            # symbolic solving for --solve (large)"
echo "      gem install one_gadget      # exact libc one-gadgets"
echo "      pip install ropper          # extra gadget search"

# make a convenient ./ctftool launcher
DIR="$(cd "$(dirname "$0")" && pwd)"
cat > "$DIR/ctftool" <<EOF
#!/usr/bin/env bash
exec python3 -m ctftool "\$@"
EOF
chmod +x "$DIR/ctftool"

echo "[*] Done. Try:  cd $DIR && ./ctftool samples/ret2win --skeleton"
