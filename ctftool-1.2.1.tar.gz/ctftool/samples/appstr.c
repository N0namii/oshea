#include <stdio.h>
#include <string.h>
int main(){
  char b[64];
  puts("myapp: enter runbook token");
  if(!fgets(b,64,stdin)) return 1;
  if(strstr(b,"SECRET")) puts("myapp: provenance accepted");
  else puts("myapp: malformed token rejected");
  return 0;
}
