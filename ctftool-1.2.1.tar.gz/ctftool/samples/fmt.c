#include <stdio.h>
int main(){ char b[128]; setvbuf(stdout,0,2,0); fgets(b,128,stdin); printf(b); return 0; }
