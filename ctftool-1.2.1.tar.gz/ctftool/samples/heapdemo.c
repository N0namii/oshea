#include <stdlib.h>
#include <string.h>
#include <stdio.h>
char *notes[10];
int main(){
  setvbuf(stdout,0,2,0);
  notes[0]=malloc(32); notes[1]=malloc(32);
  free(notes[0]); free(notes[1]);
  notes[2]=malloc(64);           // reallocation after frees
  gets(notes[2]);                // + an overflow for flavor
  free(notes[2]);
  return 0;
}
