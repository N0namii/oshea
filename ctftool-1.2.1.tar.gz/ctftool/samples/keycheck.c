#include <stdio.h>
#include <string.h>
int main(){
    char in[32];
    printf("key: ");
    if(!fgets(in,32,stdin)) return 1;
    in[strcspn(in,"\n")]=0;
    // correct key is "s3cr3t_K3Y"
    if(strcmp(in,"s3cr3t_K3Y")==0) puts("Correct! flag{...}");
    else puts("Wrong");
    return 0;
}
