#include <stdio.h>
#include <string.h>
void vuln(){ char buf[48]; read(0, buf, 300); }
int main(){ setvbuf(stdout,0,2,0); puts("go"); vuln(); return 0; }
