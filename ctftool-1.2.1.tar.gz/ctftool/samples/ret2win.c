#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
void win(){ system("/bin/sh"); }
void vuln(){ char buf[64]; gets(buf); }
int main(){ setvbuf(stdout,0,2,0); puts("overflow me"); vuln(); return 0; }
